
<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-xs-12 col-sm-9">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<fieldset>
										<legend><h2 class="text-left">About</h2></legend>
										
									On the year 2003, Elizabeth Gasataya and Family have started a business. It was Justine’s Guest House, located at # 3 Rojas Street, Kabankalan City Negros Occidental Philippines 6111. It was well renovated with 14 air conditioned rooms, Hot and Cold Shower, Cable Television and WIFI area.
									</fieldset>
								</div>
							</div>
						</div>		
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
