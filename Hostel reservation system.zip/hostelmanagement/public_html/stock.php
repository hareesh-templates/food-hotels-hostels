<?php
class stock
{
function stock($params,$tpl)
{
$tpl->display("stock.tpl");
}
}
