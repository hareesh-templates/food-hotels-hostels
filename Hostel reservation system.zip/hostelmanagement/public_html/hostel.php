
<?php
class hostel
{
function hostel($params,$tpl)
{
$tpl->display("hostel.tpl");
}
}
?>
