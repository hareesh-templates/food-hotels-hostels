<?php

class viewform2
{
	function viewform2($params,$tpl)
	{
     extract($params);
	 $_SESSION['year']=$year;
	 $_SESSION['hostelname']=$hostelname;
	 $_SESSION['month']=$month;
	
	 require_once("connection.php");
	 $rs1=$conn->Execute("select itemname,quantity,rate,amount from openingbalance
	 where hostelname='$hostelname' and year='$year' and month='$month' order by sno") or die("error");
	 
	 $rs2=$conn->Execute("select quantity,rate,amount from purchases
	 where hostelname='$hostelname' and year='$year' and month='$month' order by sno") or die("error");
	 
	 $rs3=$conn->Execute("select quantity,rate,amount from total
	 where hostelname='$hostelname' and year='$year' and month='$month' order by sno") or die("error");
	 
	 $rs4=$conn->Execute("select quantity,rate,amount from consumption
	 where hostelname='$hostelname' and year='$year' and month='$month' order by sno") or die("error");
	 
	 $rs5=$conn->Execute("select quantity,rate,amount from closingbalances
	 where hostelname='$hostelname' and year='$year' and month='$month' order by sno") or die("error");
	 
	 for($i=0;!$rs1->EOF and !$rs2->EOF and !$rs3->EOF and !$rs4->EOF and !$rs5->EOF;$i++)
	 {
	    $a[$i][0]=$i+1;
		$a[$i][1]=$rs1->fields[0];
	    $a[$i][2]=$rs1->fields[1];
		$a[$i][3]=$rs1->fields[2];
		$a[$i][4]=$rs1->fields[3];
		$openingtotal+=$a[$i][4];
	    
		$a[$i][5]=$rs2->fields[0];
		$a[$i][6]=$rs2->fields[1];
		$a[$i][7]=$rs2->fields[2];
		$purchasestotal+=$a[$i][7];
		$a[$i][8]=$rs3->fields[0];
		$a[$i][9]=$rs3->fields[1];
		$a[$i][10]=$rs3->fields[2];
		$total+=$a[$i][10];
		$a[$i][11]=$rs4->fields[0];
		$a[$i][12]=$rs4->fields[1];
		$a[$i][13]=$rs4->fields[2];
		$consumptiontotal+=$a[$i][13];
		$a[$i][14]=$rs5->fields[0];
		$a[$i][15]=$rs5->fields[1];
		$a[$i][16]=$rs5->fields[2];
		$closingtotal+=$a[$i][16];
		$rs1->MoveNext();
		$rs2->MoveNext();
		$rs3->MoveNext();
		$rs4->MoveNext();
		$rs5->MoveNext();
	 }
	 $tpl->assign('ot',$openingtotal);
     $tpl->assign('pt',$purchasestotal);
	$tpl->assign('tt',$total);
	$tpl->assign('ct',$consumptiontotal);
	$tpl->assign('clt',$closingtotal);
		
	 $tpl->assign('a',$a);
	 $tpl->assign('y',$year);
	 $tpl->assign('hostelname',$hostelname);
	 $tpl->assign('month',$month);
	 $tpl->display("viewform2.tpl");
		
		
		
	}
	}

?>
