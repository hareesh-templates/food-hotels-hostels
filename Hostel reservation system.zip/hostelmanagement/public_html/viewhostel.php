<?php
	class viewhostel
	{	   
		function viewhostel($params,$tpl)
		{				
				
				$tpl->display("viewhostel.tpl");
		}		
	}
?>
