<?php
	class viewschool
	{	   
		function viewschool($params,$tpl)
		{				
				
				$tpl->display("viewschool.tpl");
		}		
	}
?>
