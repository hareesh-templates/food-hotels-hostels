<?php
class selectview1
{
function selectview1($params,$tpl)
{
$tpl->display("selectview1.tpl");
}
}
?>