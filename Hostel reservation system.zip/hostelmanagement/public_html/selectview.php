<?php
class selectview
{
function selectview($params,$tpl)
{
$tpl->display("selectview.tpl");
}
}
?>
