
<?php
class addhostel
{
function addhostel($params,$tpl)
{
$tpl->display("addhostel.tpl");
}
}
?>