<?PHP
	class changepassword
	{
		function changepassword($params,$tpl)
		{
			//$tpl->assign("p",$params['pass']);
			$tpl->display("changepassword.tpl");
		}
	}
?>
