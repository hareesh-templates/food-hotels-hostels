<?php
class display
{
function display($params,$tpl)
{
$tpl->display("display.tpl");
}
}
?>