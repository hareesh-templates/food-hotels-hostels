
<?
class top
{
	function top($params,$tpl)
{
	$tpl->display("top.tpl");
}
}
?>
