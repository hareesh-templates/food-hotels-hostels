<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>QR Code Generator</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <script type="text/javascript" src="js/qrcode.js"></script>
    <link rel="stylesheet" href="css/plugins.css">
  <link rel="stylesheet" href="css/style.css">

</head>

<body>
  <div class="wrapper" id="wrapper">
    <!-- Start Header Area -->
    <div class="row">
    <div class="col-md-8 offset-md-2">
      <div class="card">
        <header class="htc__header bg--white">
            <!-- Start Mainmenu Area -->
            <div id="sticky-header-with-topbar" class="mainmenu__wrap sticky__header">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-sm-4 col-md-6 order-1 order-lg-1">
                            <div class="logo">
                                <a href="index.html">
                                    <img src="images/logo/foody.png" alt="logo images">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-8 col-sm-4 col-md-2 order-3 order-lg-2">
                            <div class="main__menu__wrap">
                                
                            </div>
                        </div>
                        
                    </div>
                    <!-- Mobile Menu -->
                        <div class="mobile-menu d-block d-lg-none"></div>
                    <!-- Mobile Menu -->
                </div>
            </div>
            <!-- End Mainmenu Area -->
        </header>
        <!-- End Header Area -->
    
  
      
          <div class="card-body">
             <div class="col-md-6">
          <form onsubmit="generate();return false;" method="post">
            <input type="hidden" id="qr" class="form-control" value="https://asetechnologies.in/projects/food-online/home.php" name="qr_code"><br><br>
            <input type="submit" class="btn btn-danger" value="Generate QRCode" name="btn_qr_code">
          </form>
        </div><br><br>
          <?php 
            if(isset($_POST['btn_qr_code'])){
              $qr_code = $_POST['qr_code'];
            }

          ?>

          
  <div id="qrResult" class="col-md-6">

          </div><br><br>
          <div class="col-md-6">
          <form method="post" action="home.php">
            <input type="text" name="qr_code2" placeholder="Enter QR Code here" class="form-control" required><br>
            <input type="submit" class="btn btn-danger" value="Submit" name="btn_qr_code2">
          </form>
        </div>
          </div>


      </div>
    </div>
  </div>	
  <script type="text/javascript">
    var qrcode= new QRCode(document.getElementById('qrResult'),{
    width:200,
    height:200
    });

    function generate(){
      var message = document.getElementById('qr');
      qrcode.makeCode(message.value);
    }
  </script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>