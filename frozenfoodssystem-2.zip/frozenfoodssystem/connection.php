<?php
//database connectivity
$conn=mysqli_connect("localhost","root",null,"frozensystemdb")
or die("Could not connect to server");
