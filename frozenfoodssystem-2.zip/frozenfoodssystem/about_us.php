
    <?php
    include "header.php";
    ?>
 <div >
      <div class="container">
       <center><h2 style="color: green;">About Us</h2></center> 

        <!-- <img src="images/images4.jpg"width="1500" height="500"> -->
        <h3>The purpose of Online Frozen Foods System is to automate the existing manual system by the help of computerized equipments and full-fledged computer software, fulfilling their requirements, so that their valuable data/information can be stored for a longer period with easy accessing and manipulation of the same. The required software and hardware are easily available and easy to work with.

Online Frozen Foods System, as described above, can lead to error free, secure, reliable and fast management system. It can assist the user to concentrate on their other activities rather to concentrate on the record keeping. Thus it will help organization in better utilization of resources. The organization can maintain computerized records without redundant entries. That means that one need not be distracted by information that is not relevant, while being able to reach the information.

Basically the project describes how to manage for good performance and better services for the clients.</h3>
        
      </div>
    </div>
  </div>



	