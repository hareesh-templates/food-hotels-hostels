<?php
//database connectivity
$conn=mysqli_connect("localhost","root","","frozensystemdb")
or die("Could not connect to server");
