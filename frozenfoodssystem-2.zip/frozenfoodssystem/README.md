eatFresh | Inspiring healthier habits

eatFresh is an eCommerce site based on PHP and MySQL. In addiiton to these technologies, Bootstrap
and various other CSS tools have been used to improve the UI. Google API is used to showcase various
locations of the retaurant. Key feature of this project is online order of food items served by
restaurant. This has been effectively done using the concept of PHP Session variables. User can view
the menu offered by the restaurant and its various locations. There is also a contact form if user
wants to talk to the restaurant authorities regarding some issue.